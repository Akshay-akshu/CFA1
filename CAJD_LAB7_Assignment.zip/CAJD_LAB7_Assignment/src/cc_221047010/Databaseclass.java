package cc_221047010;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
//org.h2.Driver
//jdbc:h2:tcp://localhost/e:/MyDb/sachinproductdb

public class Databaseclass {
	public static void main(String[] args)throws Exception {
		//uncomment only to create table
		/*Class.forName("org.h2.Driver");//load the driver
		Connection connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/e:/MyDb/sachinproductdb","sachin","#sunil@10");		
		String sql="create table Products"+"(PID integer,Productname varchar(100),Productunitprice float,Quantities integer, PRIMARY KEY(PID))"; 
		PreparedStatement preparedStatement=connection.prepareStatement(sql);
		//Execute the query
		int n=preparedStatement.executeUpdate();
		if(n==1) {
			System.out.println("table not created");
		}
		else {
			System.out.println("table created");
		}
		preparedStatement.close();
		connection.close();*/
		
		Productimpl p=new Productimpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice 1.insert 2.delete 3.display");
		int  n=sc.nextInt();
		if(n==1) {
			p.insertvalues();
		}
		else if(n==2) {
			p.deletevalues();
		}
		else if(n==3) {
			p.displayval();
		}
	}
}
